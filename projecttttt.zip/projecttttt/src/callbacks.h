#include <gtk/gtk.h>


void
on_ButtonAjouter_clicked               (GtkWidget *windowcap,
                                        gpointer         user_data);

void
on_buttonretouraj_clicked              (GtkWidget *windowcap,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonretouraff_clicked             (GtkWidget *windowcap,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkWidget *windowcap,
                                        gpointer         user_data);

void
on_buttonajoutcap_clicked              (GtkWidget *windowcap,
                                        gpointer         user_data);

void
on_buttonaffsupp_clicked               (GtkWidget *windowcap,
                                        gpointer         user_data);

void
on_buttonsuivant_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonconsulter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretourabs_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffich_clicked                (GtkButton       *button,
                                        gpointer         user_data);
