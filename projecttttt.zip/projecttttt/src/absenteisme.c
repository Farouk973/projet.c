#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "interface.h"
//calcul taux absenteisme
float calculer(int jourabs ,int heuretrav,float tmp )
{
float taux;
int nb=0;
FILE *f=NULL;
L=[]
f=fopen("ouvriers.txt","r+");
L=f.readlines()
nb=len(L)
fclose(f);
taux=((jourtrav*tmp)/(nb*heuretrav*(30-jourabs)))*100;
return(taux);
