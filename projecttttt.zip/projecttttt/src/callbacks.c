#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteurs.h"



void
on_ButtonAjouter_clicked               (GtkWidget       *windowcap,
                                        gpointer         user_data)
{
GtkWidget *id, *mar, *ty, *prix, *etat, *jour, *mois, *an, *success, *p;
Capteur C;

//les entries +label sucess
id=lookup_widget(windowcap,"entryid");
mar=lookup_widget(windowcap,"entrymar");
ty=lookup_widget(windowcap,"comboboxtype");
prix=lookup_widget(windowcap,"spinbuttonprix");
etat=lookup_widget(windowcap,"spinbuttonetat");
jour=lookup_widget(windowcap,"jour");
mois=lookup_widget(windowcap,"mois");
an=lookup_widget(windowcap,"ans");
success=lookup_widget(windowcap,"labelsuccess");


//Récuperation de l'identifiant 
strcpy(C.identifiant, gtk_entry_get_text(GTK_ENTRY(id)));

//Récuperation de la marque 
strcpy(C.marque, gtk_entry_get_text(GTK_ENTRY(mar)));

//Récuperation du type 
strcpy(C.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ty)));

//Récuperation du prix
C.prix=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(prix));
//Récuperation de l'état
C.etat=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etat));
//Récuperation du jour
C.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
//Récuperation du mois
C.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
//Récuperation de l'années
C.an=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

ajouter_capteur(C);
//mise à jour du treeview
p=lookup_widget(windowcap,"treeview1");
Capteurtree(p,"capteurs.txt");
//bien ajouté 
gtk_widget_show(success);
//vider les champs après ajout
gtk_entry_set_text(GTK_ENTRY(id),"");
gtk_entry_set_text(GTK_ENTRY(mar),"");
gtk_spin_button_set_value(GTK_SPIN_BUTTON(prix),20);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(etat),0);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour),1);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois),1);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(an),2000);
}


void
on_buttonretouraj_clicked              (GtkWidget *windowcap,
                                        gpointer         user_data)
{
GtkWidget *windowwelcome, *windowaj, *p;

windowwelcome=create_windowwelcomecap();
windowaj=lookup_widget(windowcap,"fenetreajout");
p=lookup_widget(windowwelcome,"treeview1");
Capteurtree(p,"capteurs.txt");
gtk_widget_destroy(windowaj);
gtk_widget_show(windowwelcome);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_buttonretouraff_clicked             (GtkWidget *windowcap,
                                        gpointer         user_data)
{
GtkWidget *p;
GtkWidget *windowwelcome, *windowaffsupp;

windowwelcome=create_windowwelcomecap();

windowaffsupp=lookup_widget(windowcap,"treeviewcapt");
p=lookup_widget(windowwelcome,"treeview1");
Capteurtree(p,"capteurs.txt");

gtk_widget_destroy(windowaffsupp);
gtk_widget_show(windowwelcome);
}


void
on_buttonsupp_clicked                  (GtkWidget *windowcap,
                                        gpointer         user_data)
{
	GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *suc, *p;
        gchar* id;
        suc=lookup_widget(windowcap,"labelsupp");
        p=lookup_widget(windowcap,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection,&model,&iter))
        {  
		gtk_tree_model_get (model,&iter,0,&id,-1);
		gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView
		supprimer_capteur(id);// supprimer la ligne du fichier
           	gtk_widget_show(suc);
	}
			
}


void
on_buttonajoutcap_clicked              (GtkWidget *windowcap,
                                        gpointer         user_data)
{
GtkWidget *windowwelcome, *windowaj, *p;

windowaj=create_fenetreajout();

windowwelcome=lookup_widget(windowcap,"windowwelcomecap");
p=lookup_widget(windowaj,"treeview1");
Capteurtree(p,"capteurs.txt");
gtk_widget_destroy(windowwelcome);
gtk_widget_show(windowaj);
}


void
on_buttonaffsupp_clicked               (GtkWidget *windowcap,
                                        gpointer         user_data)
{
GtkWidget *p;
GtkWidget *windowwelcome, *windowaffsupp;

windowaffsupp=create_treeviewcapt();

p=lookup_widget(windowaffsupp,"treeview1");
Capteurtree(p,"capteurs.txt");

windowwelcome=lookup_widget(windowcap,"windowwelcomecap");

gtk_widget_destroy(windowwelcome);
gtk_widget_show(windowaffsupp);
}


void
on_buttonsuivant_clicked               (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *p;
GtkWidget *windowaffsupp, *windowabs;

windowabs=create_windowabsent();



windowaffsupp=lookup_widget(objet,"treeviewcapt");

gtk_widget_destroy(windowaffsupp);
gtk_widget_show(windowabs);
}


void
on_buttonconsulter_clicked             (GtkWidget       *windowcap,
                                        gpointer         user_data)
{

GtkWidget *jourabs, *heuretrav, *tmp, *p;

jourabss=lookup_widget(windowcap,"entryjourabs");
heuretravv=lookup_widget(windowcap,"entryheuretrav");
tmpp=lookup_widget(windowcap,"entrytmp");

//Récuperation de jour dabsence 
strcpy(jourabs, gtk_entry_get_text(GTK_ENTRY(jourabs)));

//Récuperation de temp d'absence 
strcpy(tmp, gtk_entry_get_text(GTK_ENTRY(tmp)));

//Récuperation d'heure de travail 
strcpy(heuretrav, gtk_entry_get_text(GTK_ENTRY(heuretrav)));


calculer(jourabs,heuretrav,tmp);


}


void
on_buttonretourabs_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowabs, *windowaffsupp, *p;

windowaffsupp=create_treeviewcapt();
windowabs=lookup_widget(objet,"windowabsent");
p=lookup_widget(windowaffsupp,"treeview1");

gtk_widget_destroy(windowabs);
gtk_widget_show(windowaffsupp);

}


void
on_buttonaffich_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *p;
GtkWidget *windowaj, *windowaffsupp;

windowaffsupp=create_treeviewcapt();

p=lookup_widget(windowaj,"treeview1");


windowaj=lookup_widget(objet,"fenetreajout");

gtk_widget_destroy(windowaj);
gtk_widget_show(windowaffsupp);

}

