#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "interface.h"
#include "capteurs.h"
//fonction ajout
void ajouter_capteur(Capteur C)
{
FILE *f=NULL;
f=fopen("capteurs.txt","a");
if(f==NULL)
{
printf("Impossible d'ouvrir le fichier");
}
else
{
fprintf(f,"%s %s %s %d %d %d %d %d\n",C.identifiant,C.marque,C.type,C.prix,C.etat,C.jour,C.mois,C.an);
fclose(f);
}
}
//fonction suprresion
void supprimer_capteur(char *id)
{
FILE*f=NULL;
FILE*f1=NULL;
Capteur C ;
f=fopen("capteurs.txt","r");
f1=fopen("ancienscap.txt","w+");
while(fscanf(f,"%s %s %s %d %d %d %d %d\n",C.identifiant,C.marque,C.type,&C.prix,&C.etat,&C.jour,&C.mois,&C.an)!=EOF)
{
if(strcmp(id,C.identifiant)!=0)
	{fprintf(f1,"%s %s %s %d %d %d %d %d\n",C.identifiant,C.marque,C.type,C.prix,C.etat,C.jour,C.mois,C.an);}
}
fclose(f);
fclose(f1);
remove("capteurs.txt");
rename("ancienscap.txt","capteurs.txt");
}
//tree
GtkListStore *adstore;//creation du modele de type liste
GtkTreeViewColumn *adcolumn;//visualisation des colonnes
GtkCellRenderer *cellad; //afficheur de cellule(text,image..)
FILE *f=NULL;
int i;
void Capteurtree(GtkWidget* treeview1,char*l)
{

Capteur C;
	
        // Creation du modele 
        adstore = gtk_list_store_new(8,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
                                     G_TYPE_STRING,
				     G_TYPE_INT,
                                     G_TYPE_INT,
                                     G_TYPE_INT,
				     G_TYPE_INT,
				     G_TYPE_INT);
        //Insertion des élements 
        f=fopen(l,"r");

        {GtkTreeIter pIter;
while(fscanf(f,"%s %s %s %d %d %d %d %d\n",C.identifiant,C.marque,C.type,&C.prix,&C.etat,&C.jour,&C.mois,&C.an)!=EOF)
         //Creation de la nouvelle ligne
         gtk_list_store_append(adstore,&pIter);
         // Mise a jour des données
         gtk_list_store_set(adstore, &pIter,
                            0,C.identifiant,
                            1,C.marque,
                            2,C.type,
                            3,C.prix,
                            4,C.etat,
                            5,C.jour,
			    6,C.mois,
			    7,C.an,
                            -1);}
        fclose(f);

	//Creation de la 1ère colonne 
if(i==0)
	{
	cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("identifiant",
                                                            cellad,
                                                            "text", 0,
                                                            NULL);


        //Ajouter la 1ère colonne à la vue
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);


	//Creation de la 2ème colonne 
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("marque",
                                                            cellad,
                                                            "text", 1,
                                                            NULL);
	//Ajouter la 2ème colonne à la vue 
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	//Creation de la 3ème colonne 
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("type",
                                                            cellad,
                                                            "text", 2,
                                                            NULL);
	//Ajouter la 3ème colonne à la vue 
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	//Creation de la 4ème colonne 
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("prix",
                                                            cellad,
                                                            "text", 3,
                                                            NULL);
	//Ajouter la 4ème colonne à la vue 
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	//Creation de la 5ème colonne
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("etat",
                                                            cellad,
                                                            "text", 4,
                                                            NULL);
	//Ajouter la 5ème colonne à la vue
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	//Creation de la 6ème colonne
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("jour",
                                                            cellad,
                                                            "text", 5,
                                                            NULL);
	//Ajouter la 6ème colonne à la vue 
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	//Creation de la 7ème colonne
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("mois",
                                                            cellad,
                                                            "text", 6,
                                                            NULL);
	//Ajouter la 7ème colonne à la vue 
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	//Creation de la 8ème colonne
        cellad = gtk_cell_renderer_text_new();
        adcolumn = gtk_tree_view_column_new_with_attributes("an",
                                                            cellad,
                                                            "text", 7,
                                                            NULL);
	//Ajouter la 8ème colonne à la vue 
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview1), adcolumn);

	i++;}


 	gtk_tree_view_set_model(GTK_TREE_VIEW (treeview1),
                                  GTK_TREE_MODEL(adstore));

}


