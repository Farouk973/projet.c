#include <gtk/gtk.h>
typedef struct
{ 
char jourEqui[20] ;
char moisEqui[20] ;
char anneeEqui[20] ;
}datesE;

typedef struct
{
char idEqui[30];
char nomEqui [30];
char typeEqui[30];
char marqueEqui[30];
char prixEqui[10];

//char panneEqui[3];
datesE dateEqui;

}equip ;

void ajouter_equipement(equip e);
void afficher_equipement(GtkWidget  *liste);
void supprimer_equipement(equip e);
