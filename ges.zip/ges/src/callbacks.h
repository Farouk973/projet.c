#include <gtk/gtk.h>


void
on_AffichageAequi_clicked              (GtkWidget     *button,
                                        gpointer         user_data);

void
on_buttonAEqui_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonModifierASEqui_clicked        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_treeviewEqui_row_activated          (GtkWidget     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonSupprimerASEqui_clicked       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_butoonc_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonRetourEqui_clicked            (GtkWidget       *button,
                                        gpointer         user_data);
