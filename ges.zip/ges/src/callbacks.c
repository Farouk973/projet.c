#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "equipement.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_AffichageAequi_clicked              (GtkWidget      *button,
                                        gpointer         user_data)
{

GtkWidget *fajoutEqui;
GtkWidget *fafficheEqui;
GtkWidget *treeviewAEqui;

fajoutEqui = lookup_widget(button, "AjoutEquipement");
gtk_widget_destroy(fajoutEqui);
fafficheEqui= lookup_widget(button, "AfficheSupprimeEqui");
fafficheEqui= create_AfficheSupprimeEqui();
gtk_widget_show(fafficheEqui);
treeviewAEqui= lookup_widget(fafficheEqui , "treeviewEqui");
afficher_equipement(treeviewAEqui);

}


void
on_buttonAEqui_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{
equip e; int j,m,a;
GtkWidget *idEQ;
GtkWidget *nomEQ;
GtkWidget *typeEQ;
GtkWidget *marqueEQ;
GtkWidget *prixEQ;
GtkWidget *panneEQ;
GtkWidget *jourEQ;
GtkWidget *moisEQ;
GtkWidget *anneeEQ;
GtkWidget *comboboxEQ;
GtkWidget *sortie;
//association des objets avec les variables

 idEQ = lookup_widget(button , "entryIdAEqui");
 nomEQ = lookup_widget(button, "entryNomAEqui");
 typeEQ =lookup_widget(button, "entryTypeAEqui");
 marqueEQ = lookup_widget(button, "entryMarqueAEqui");
 prixEQ =  lookup_widget(button, "entryPrixAEqui");
 jourEQ = lookup_widget(button,"spinbuttonJourAEqui");
 moisEQ =lookup_widget(button,"spinbuttonMoisAEqui");
 anneeEQ =lookup_widget(button,"spinbuttonAnneeAEqui");
 comboboxEQ = lookup_widget(button,"comboboxAEqui");
 sortie =lookup_widget(button,"AjoutReuissi");

//Recuperation des valeurs 

  j= gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jourEQ));
	sprintf(e.dateEqui.jourEqui,"%d",j); // pour convertir un entier à une chaine
  m= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisEQ));
	sprintf(e.dateEqui.moisEqui,"%d",m); // pour convertir un entier à une chaine

  a= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneeEQ));
  sprintf(e.dateEqui.anneeEqui,"%d",m);

// strcpy(e.panneEqui, gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxEQ)));
 strcpy(e.idEqui, gtk_entry_get_text(GTK_ENTRY(idEQ)));
 strcpy(e.nomEqui, gtk_entry_get_text(GTK_ENTRY(nomEQ)));
 strcpy(e.typeEqui, gtk_entry_get_text(GTK_ENTRY(typeEQ)));
 strcpy(e.marqueEqui, gtk_entry_get_text(GTK_ENTRY(marqueEQ)));
 strcpy(e.prixEqui, gtk_entry_get_text(GTK_ENTRY(prixEQ)));

 ajouter_equipement(e);
gtk_label_set_text(GTK_LABEL(sortie),"AJOUT EQUIPEMENT  Réussi");

}


void
on_buttonModifierASEqui_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{

}
void
on_treeviewEqui_row_activated          (GtkWidget    *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)

{


GtkTreeIter iter;
gchar *id;
gchar *nom;
gchar *type;

gchar *marque;
gchar *prix;
gchar *jour;
gchar *mois;
gchar *annee;

equip e;
 GtkTreeModel * model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model, &iter, path))
{
		gtk_tree_model_get(GTK_LIST_STORE(model),&iter, 0, &id,1,&nom,2,&type,3, &marque, 4, &prix,5, &jour, 6, &mois, 7, &annee,-1);
		strcpy(e.idEqui, id);
		strcpy(e.nomEqui, nom);
		strcpy(e.typeEqui, type);
		strcpy(e.marqueEqui, marque);
		strcpy(e.prixEqui, prix);
		strcpy(e.dateEqui.jourEqui, jour);
		strcpy(e.dateEqui.moisEqui, mois);
		strcpy(e.dateEqui.anneeEqui, annee);

supprimer_equipement(e);
afficher_equipement (treeview);


	}
}


void
on_buttonSupprimerASEqui_clicked       (GtkWidget       *button,
                                        gpointer         user_data)
{/*
GtkTreeIter iter;
GtkTreeView *treeView;
equip e;

gchar *id;
gchar *nom;
gchar *type;

gchar *marque;
gchar *prix;
gchar *jour;
gchar *mois;
gchar *annee;

gtk_tree_model_get(GTK_LIST_STORE(model),&iter, 0, &id,1,&nom,2,&type,3, &marque, 4, &prix,5, &jour, 6,&mois, 7, &annee,-1);
		strcpy(e.idEqui, id);
		strcpy(e.nomEqui, nom);
		strcpy(e.typeEqui, type);
		strcpy(e.marqueEqui, marque);
		strcpy(e.prixEqui, prix);
		strcpy(e.dateEqui.jourEqui, jour);
		strcpy(e.dateEqui.moisEqui, mois);
		strcpy(e.dateEqui.anneeEqui, annee);


 
supprimer_equipement( e);
afficher_equipement (treeView);
*/
}


void
on_butoonc_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonRetourEqui_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget * fajout, *faffiche;
faffiche = lookup_widget(button, "AfficheSupprimeEqui");
gtk_widget_destroy(faffiche);
fajout = create_AjoutEquipement();
gtk_widget_show(fajout);
}

