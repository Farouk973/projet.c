#include<stdio.h>
#include<stdlib.h>
#include "equipement.h"
#include <string.h>
#include <gtk/gtk.h>
enum{
	IdEQ,
	NoEQ,
	MaEQ,
	TyEQ,
	PrEQ,
	DtEQ,
	MsEQ,
	AnEQ,
       COLUMNS
};

//Ajouter un equipement 

void ajouter_equipement (equip e )
 {

    FILE* fichier = NULL;

    fichier = fopen("equipement.txt", "a+");

    if (fichier != NULL)
    {
	
        // On peut lire et écrire dans le fichier
        fprintf (fichier,"%s %s %s %s %s %s %s %s \n", e.idEqui ,e.nomEqui ,e.typeEqui ,e.marqueEqui ,e.prixEqui,
        e.dateEqui.jourEqui , e.dateEqui.moisEqui , e.dateEqui.anneeEqui); //f variable de type file

    }

fclose(fichier); //retour NULL si operation fini 
}
//********************************************************
void afficher_equipement ( GtkWidget  *liste)
{



GtkCellRenderer *renderer;  
	GtkTreeViewColumn *column;
	GtkTreeIter   iter;   
	GtkListStore  *store;    

char idEqui[20];
char nomEqui [20];
char typeEqui[20];
char marqueEqui[20];
char prixEqui[20];
char jour[20];
char mois[20];
char annee[20];


	
	 store=NULL;
	 FILE *F;

	store=gtk_tree_view_get_model(liste);//va prendre comme variable de la liste
	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new (); //cellule contenant du texte
	column = gtk_tree_view_column_new_with_attributes("Identifiant", 		renderer,"text",IdEQ,NULL);//creation d'une colonne avec du 		texte
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);//associer 		la colonne à l'afficher (GtkTreeView);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Nom d'équipement", 		  renderer,"text",NoEQ,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Type", 		  renderer,"text",TyEQ,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Marque", 		renderer,"text",MaEQ,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Prix", 		  renderer,"text",PrEQ,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Jour", 		  renderer,"text",DtEQ,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Mois", 		renderer,"text",MsEQ,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new (); 
	column = gtk_tree_view_column_new_with_attributes("Année", 		renderer,"text",AnEQ,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	}

	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
F=fopen("equipement.txt","r");
if(F==NULL)
{
	return;
}
else
{ 
   F=fopen("equipement.txt","a+");
   while(fscanf(F,"%s %s %s %s %s %s %s %s \n",idEqui,nomEqui,typeEqui,marqueEqui,prixEqui,jour,mois,annee)!=EOF)
{       

        	
gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,IdEQ,idEqui,NoEQ,nomEqui,TyEQ,typeEqui,MaEQ,marqueEqui,PrEQ,prixEqui,DtEQ,jour,MsEQ,mois,AnEQ,annee, -1);
}
	fclose(F);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));//
	g_object_unref (store);
}
  }
void supprimer_equipement(equip e)
{

int jourEqui ;
int moisEqui ;
int anneeEqui ;
char idEqui[30];
char nomEqui [30];
char typeEqui[30];
char marqueEqui[30];
char prixEqui[10];

FILE *f, *g;
f = fopen("equipement.txt", "r");
g = fopen("dump.txt", "w");
 
   if (f==NULL|| g ==NULL)
      {return;}

   else
   {
    while(fscanf(f, "%s %s %s %s %s %d %d %d " ,idEqui,nomEqui, typeEqui, marqueEqui,prixEqui, jourEqui, moisEqui, anneeEqui)!=EOF)
     {   
      if (strcmp(e.idEqui , idEqui)!=0 || strcmp(e.nomEqui , nomEqui)!=0||strcmp(e.typeEqui , typeEqui)!=0||
       strcmp(e.marqueEqui , marqueEqui)!=0||strcmp(e.prixEqui , prixEqui)!=0||
       strcmp(e.dateEqui.jourEqui , jourEqui)!=0||strcmp(e.dateEqui.moisEqui , moisEqui)!=0 ||strcmp(e.dateEqui.anneeEqui , anneeEqui)!=0 )

        fprintf (g,"%s %s %s %s %s  %d %d %d \n", e.idEqui ,e.nomEqui ,e.typeEqui ,e.marqueEqui ,e.prixEqui,
        e.dateEqui.jourEqui , e.dateEqui.moisEqui , e.dateEqui.anneeEqui);

     }
      fclose(f);
      fclose(g);
      remove("equipement.txt");
      rename("dump.txt", "equipement.txt");
   }
}









































