#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ouvrier.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int x;
int x1;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fhomme_ajouter_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   {x=1;}

}
void
on_Ffemme_ajouter_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
  {x=2;}

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fajouter_ajouter_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
ouvrier a;
int v1,v2,v4,v3,v5;
GtkWidget *Fnom_ajouter;
GtkWidget *Fprenom_ajouter;
GtkWidget *Fcin_ajouter;
GtkWidget *Ftel_ajouter;
GtkWidget *Fage_ajouter;
GtkWidget *Fjour_ajouter;
GtkWidget *Fmois_ajouter;
GtkWidget *Fans_ajouter;
GtkWidget *Fsortie_ajouter,*Fsortie_ajouter1,*Fsortie_ajouter2,*Fsortie_ajouter3,*Fsortie_ajouter4;

GtkWidget *Ajouter_ouvrier;

Ajouter_ouvrier=lookup_widget(button,"Ajouter_ouvrier");

Fnom_ajouter=lookup_widget(button,"Fnom_ajouter");
Fprenom_ajouter=lookup_widget(button,"Fprenom_ajouter");
Fcin_ajouter=lookup_widget(button,"Fcin_ajouter");
Ftel_ajouter=lookup_widget(button,"Ftel_ajouter");
Fage_ajouter=lookup_widget(button,"Fage_ajouter");
Fjour_ajouter=lookup_widget(button,"Fjour_ajouter");
Fmois_ajouter=lookup_widget(button,"Fmois_ajouter");
Fans_ajouter=lookup_widget(button,"Fans_ajouter");
Fsortie_ajouter=lookup_widget(button,"Fsortie_ajouter");
Fsortie_ajouter1=lookup_widget(button,"Fsortie_ajouter1");
Fsortie_ajouter2=lookup_widget(button,"Fsortie_ajouter2");
Fsortie_ajouter3=lookup_widget(button,"Fsortie_ajouter3");
Fsortie_ajouter4=lookup_widget(button,"Fsortie_ajouter4");

strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(Fcin_ajouter)));
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(Fnom_ajouter)));
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(Fprenom_ajouter)));
strcpy(a.tel,gtk_entry_get_text(GTK_ENTRY(Ftel_ajouter)));

a.age=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fage_ajouter));

a.dt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fjour_ajouter));
a.dt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fmois_ajouter));
a.dt.ans=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fans_ajouter));

if (x==1)
    strcpy(a.sexe,"Homme");
if (x==2)
    strcpy(a.sexe,"Femme");



v1=numbers(a.cin);

v2=numbers(a.tel);

v3=alphabet(a.nom);

v4=alphabet(a.prenom);
v5=rechercher(a.cin);

if(v3==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter2),"nom ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter2),"nom false.");

if(v4==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter3),"prenom ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter3),"prenom false.");
if(v2==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter1),"tel ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter1),"tel false.");
if(v1==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_ajouter),"numero ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_ajouter),"numero false.");
if ((v1==1)&&(v2==1)&&(v3==1)&&(v4==1)&&(v5==0))
	{  gtk_label_set_text(GTK_LABEL(Fsortie_ajouter4),"l'ouvrier a été ajouté.");
	   ajouter_ouvrier(a);
	}
else if (v5==1){gtk_label_set_text(GTK_LABEL(Fsortie_ajouter4),"cette cin existe déja");}
else {gtk_label_set_text(GTK_LABEL(Fsortie_ajouter4),"saisir les entrées convenablement.");}


}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Finfo_gestion_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *infos_ouvrier;
GtkWidget *tree_info;
GtkWidget *gestion_ouvrier;
gestion_ouvrier=lookup_widget(button,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
infos_ouvrier=lookup_widget(button,"infos_ouvrier");
infos_ouvrier=create_infos_ouvrier();
tree_info=lookup_widget(infos_ouvrier,"tree_info");
affichier_ouvrier(tree_info);
gtk_widget_show(infos_ouvrier);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fajouter_gestion_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajouter_ouvrier;
GtkWidget *gestion_ouvrier;
gestion_ouvrier=lookup_widget(button,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
Ajouter_ouvrier=create_Ajouter_ouvrier();
gtk_widget_show(Ajouter_ouvrier);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fsupprimer_gestion_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimer_ouvrier;
GtkWidget *gestion_ouvrier;
gestion_ouvrier=lookup_widget(button,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
supprimer_ouvrier=create_supprimer_ouvrier();
gtk_widget_show(supprimer_ouvrier);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fmeilleur_gestion_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Meilleur_ouvrier;
GtkWidget *gestion_ouvrier;
gestion_ouvrier=lookup_widget(button,"gestion_ouvrier");
gtk_widget_destroy(gestion_ouvrier);
Meilleur_ouvrier=create_Meilleur_ouvrier();
gtk_widget_show(Meilleur_ouvrier);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fannuler_ajouter_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajouter_ouvrier;
GtkWidget *gestion_ouvrier;
Ajouter_ouvrier=lookup_widget(button,"Ajouter_ouvrier");
gtk_widget_destroy(Ajouter_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fanuuler_retirer_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimer_ouvrier;
GtkWidget *gestion_ouvrier;
supprimer_ouvrier=lookup_widget(button,"supprimer_ouvrier");
gtk_widget_destroy(supprimer_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fannuler_modifier_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *infos_ouvrier;
GtkWidget *Modifier_ouvrier;
GtkWidget *tree_info;
Modifier_ouvrier=lookup_widget(button,"Modifier_ouvrier");
gtk_widget_destroy(Modifier_ouvrier);
infos_ouvrier=create_infos_ouvrier();
tree_info=lookup_widget(infos_ouvrier,"tree_info");
affichier_ouvrier(tree_info);
gtk_widget_show(infos_ouvrier);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_Fmodifier_info_clicked              (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *infos_ouvrier;
GtkWidget *Modifier_ouvrier;
infos_ouvrier=lookup_widget(button,"infos_ouvrier");
gtk_widget_destroy(infos_ouvrier);
Modifier_ouvrier=create_Modifier_ouvrier();
gtk_widget_show(Modifier_ouvrier);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fretourner_info_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *infos_ouvrier;
GtkWidget *gestion_ouvrier;
infos_ouvrier=lookup_widget(button,"infos_ouvrier");
gtk_widget_destroy(infos_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fretourner_meilleur_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Meilleur_ouvrier;
GtkWidget *gestion_ouvrier;
Meilleur_ouvrier=lookup_widget(button,"Meilleur_ouvrier");
gtk_widget_destroy(Meilleur_ouvrier);
gestion_ouvrier=create_gestion_ouvrier();
gtk_widget_show(gestion_ouvrier);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Ffemme_win_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   {x1=1;}
}
void
on_Fhomme_win_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
   {x1=2;}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fannuler_win_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier_ouvrier;
GtkWidget *infos_ouvrier;
GtkWidget *tree_info;
modifier_ouvrier=lookup_widget(button,"modifier_ouvrier");
gtk_widget_destroy(modifier_ouvrier);
infos_ouvrier=lookup_widget(button,"infos_ouvrier");
infos_ouvrier=create_infos_ouvrier();
tree_info=lookup_widget(infos_ouvrier,"tree_info");
affichier_ouvrier(tree_info);
gtk_widget_show(infos_ouvrier);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fmodifier_win_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
ouvrier a5;
int v1,v2,v4,v3,v5;
GtkWidget *Fnom_win;
GtkWidget *Fprenom_win;
GtkWidget *Fcin_win;
GtkWidget *Ftel_win;
GtkWidget *Fage_win;
GtkWidget *Fjour_win;
GtkWidget *Fmois_win;
GtkWidget *Fans_win;
GtkWidget *Fsortie_win1,*Fsortie_win2,*Fsortie_win3,*Fsortie_win4,*Fsortie_win10;

GtkWidget *modifier_ouvrier;
modifier_ouvrier=lookup_widget(button,"modifier_ouvrier");


Fnom_win=lookup_widget(button,"Fnom_win");
Fprenom_win=lookup_widget(button,"Fprenom_win");
Fcin_win=lookup_widget(button,"Fcin_win");
Ftel_win=lookup_widget(button,"Ftel_win");
Fage_win=lookup_widget(button,"Fage_win");
Fjour_win=lookup_widget(button,"Fjour_win");
Fmois_win=lookup_widget(button,"Fmois_win");
Fans_win=lookup_widget(button,"Fans_win");


Fsortie_win1=lookup_widget(button,"Fsortie_win1");
Fsortie_win2=lookup_widget(button,"Fsortie_win2");
Fsortie_win3=lookup_widget(button,"Fsortie_win3");
Fsortie_win4=lookup_widget(button,"Fsortie_win4");
Fsortie_win10=lookup_widget(button,"Fsortie_win10");


strcpy(a5.cin,gtk_entry_get_text(GTK_ENTRY(Fcin_win)));
strcpy(a5.nom,gtk_entry_get_text(GTK_ENTRY(Fnom_win)));
strcpy(a5.prenom,gtk_entry_get_text(GTK_ENTRY(Fprenom_win)));
strcpy(a5.tel,gtk_entry_get_text(GTK_ENTRY(Ftel_win)));
a5.age=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fage_win));
a5.dt.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fjour_win));
a5.dt.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fmois_win));
a5.dt.ans=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fans_win));
a5.abs=0;
a5.supp=0;
if (x1==1)
    strcpy(a5.sexe,"Homme");
if (x1==2)
    strcpy(a5.sexe,"Femme");
//v1=test(a.cin);
v1=numbers(a5.cin);
//v2=test(a.tel);
v2=numbers(a5.tel);
//v3=test2(a.nom);
v3=alphabet(a5.nom);
//v4=test2(a.prenom);
v4=alphabet(a5.prenom);
if (strcmp(array,a5.cin)==0){v5=0;}
else v5=rechercher(a5.cin);


if(v3==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_win2),"nom ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_win2),"nom false.");

if(v4==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_win3),"prenom ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_win3),"prenom false.");
if(v2==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_win4),"tel ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_win4),"tel false.");
if(v1==1) {
   gtk_label_set_text(GTK_LABEL(Fsortie_win1),"numero ok.");
}else 
gtk_label_set_text(GTK_LABEL(Fsortie_win1),"numero false.");
if ((v1==1)&&(v2==1)&&(v3==1)&&(v4==1)&&(v5==0))
	{  modifier__ouvrier(a5);
           gtk_label_set_text(GTK_LABEL(Fsortie_win10),"l'ouvrier a été modifier.");
	}
else if (v5==1){gtk_label_set_text(GTK_LABEL(Fsortie_win10),"cette cin existe déja");}
else {gtk_label_set_text(GTK_LABEL(Fsortie_win10),"saisir les entrées convenablement.");}

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_entrer_verifier_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier_ouvrier;
GtkWidget *Verifier_cin;
GtkWidget *Fancin_win;
GtkWidget *Fsortie_win;
Fsortie_win=lookup_widget(button,"Fsortie_win");
Fancin_win=lookup_widget(button,"Fancin_win");
strcpy(array,gtk_entry_get_text(GTK_ENTRY(Fancin_win)));
if (rechercher(array)==0){gtk_label_set_text(GTK_LABEL(Fsortie_win),"verifier le cin");}
if (rechercher(array)==1){Verifier_cin=lookup_widget(button,"Verifier_cin");
			   gtk_widget_destroy(Verifier_cin);
			   modifier_ouvrier=create_modifier_ouvrier();
			   gtk_widget_show(modifier_ouvrier);}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_retourner_verifier_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *Verifier_cin;
GtkWidget *infos_ouvrier;
GtkWidget *tree_info;
Verifier_cin=lookup_widget(button,"Verifier_cin");
gtk_widget_destroy(Verifier_cin);
infos_ouvrier=lookup_widget(button,"infos_ouvrier");
infos_ouvrier=create_infos_ouvrier();
tree_info=lookup_widget(infos_ouvrier,"tree_info");
affichier_ouvrier(tree_info);
gtk_widget_show(infos_ouvrier);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_Fmodifier_info_ouvrier_clicked      (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *infos_ouvrier;
GtkWidget *Verifier_cin;
infos_ouvrier=lookup_widget(button,"infos_ouvrier");
gtk_widget_destroy(infos_ouvrier);
Verifier_cin=create_Verifier_cin();
gtk_widget_show(Verifier_cin);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fretourner_gestion_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fchercher_win_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
FILE *f;
ouvrier a;
char ch1[30],ch2[30],ch3[30],ch4[30],ch5[30],q[30],s[30],d[30],j[30],g[30],h[30];
//int q,s,d,j,g,h;
GtkWidget *Fsortie_win1,*Fsortie_win2,*Fsortie_win3,*Fsortie_win4,*Fsortie_win5,*Fsortie_win6,*Fsortie_win7,*Fsortie_win8,*Fsortie_win9;
Fsortie_win1=lookup_widget(button,"Fsortie_win1");
Fsortie_win2=lookup_widget(button,"Fsortie_win2");
Fsortie_win3=lookup_widget(button,"Fsortie_win3");
Fsortie_win4=lookup_widget(button,"Fsortie_win4");
Fsortie_win5=lookup_widget(button,"Fsortie_win5");
Fsortie_win6=lookup_widget(button,"Fsortie_win6");
Fsortie_win7=lookup_widget(button,"Fsortie_win7");
Fsortie_win8=lookup_widget(button,"Fsortie_win8");
Fsortie_win9=lookup_widget(button,"Fsortie_win9");
f=fopen("ouvrier.txt","r");
if (f!=NULL) 
{ while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",ch1,ch2,ch3,ch4,ch5,q,s,d,j,g,h)!=EOF)
       { if (strcmp(array,ch1)==0)
	  {gtk_label_set_text(GTK_LABEL(Fsortie_win1),ch1);
	   gtk_label_set_text(GTK_LABEL(Fsortie_win2),ch2);
	   gtk_label_set_text(GTK_LABEL(Fsortie_win3),ch3);
	   gtk_label_set_text(GTK_LABEL(Fsortie_win4),ch5);
	   gtk_label_set_text(GTK_LABEL(Fsortie_win6),ch4);
	   gtk_label_set_text(GTK_LABEL(Fsortie_win5),q);
	   gtk_label_set_text(GTK_LABEL(Fsortie_win7),s);
	   gtk_label_set_text(GTK_LABEL(Fsortie_win8),d); 
	   gtk_label_set_text(GTK_LABEL(Fsortie_win9),j);}}
}
fclose(f);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fenregistrer_modifier_clicked       (GtkWidget       *button,
                                        gpointer         user_data)
{
char cin[30];
ouvrier a;
int abs,supp,v;
GtkWidget *Fcin_modifier;
GtkWidget *Fabs_modifier;
GtkWidget *Fsupp_modifier;
GtkWidget *Fsortie_modifier;
FILE *f,*k;
Fcin_modifier=lookup_widget(button,"Fcin_modifier");
Fabs_modifier=lookup_widget(button,"Fabs_modifier");
Fsupp_modifier=lookup_widget(button,"Fsupp_modifier");
Fsortie_modifier=lookup_widget(button,"Fsortie_modifier");
abs=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fabs_modifier));
supp=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Fsupp_modifier));
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(Fcin_modifier)));
int test9=0;
f=fopen("ouvrier.txt","r");
k=fopen("ouvrier3.txt","w");
if (f!=NULL) 
 { while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n",a.cin, a.nom, a.prenom, a.sexe ,a.tel,&a.age, &a.dt.jour, &a.dt.mois, &a.dt.ans, &a.abs, &a.supp)!=EOF)
    { if (strcmp(cin,a.cin)==0){a.abs=a.abs+abs;
                                a.supp=a.supp+supp;
                                test9=1;
                                fprintf(k,"%s %s %s %s %s %d %d %d %d %d %d \n",a.cin, a.nom, a.prenom, a.sexe ,a.tel,a.age, a.dt.jour, a.dt.mois, a.dt.ans, a.abs, a.supp);}
else fprintf(k,"%s %s %s %s %s %d %d %d %d %d %d \n",a.cin, a.nom, a.prenom,a.sexe, a.tel, a.age,a.dt.jour, a.dt.mois, a.dt.ans, a.abs, a.supp);
}
    }
 
fclose(f);
fclose(k);
remove("ouvrier.txt");
rename("ouvrier3.txt","ouvrier.txt");
if (test9==1)
    {gtk_label_set_text(GTK_LABEL(Fsortie_modifier),"l'ouvrier a été modifié.");}
if (test9==0){gtk_label_set_text(GTK_LABEL(Fsortie_modifier),"saisir les entrées convenablement.");}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_Fsupprimer_supprimer_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
char cin[30];
GtkWidget *Fcin_retirer;
GtkWidget *Fsortie_retirer;
ouvrier a;
Fsortie_retirer=lookup_widget(button,"Fsortie_retirer");
Fcin_retirer=lookup_widget(button,"Fcin_retirer");
strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(Fcin_retirer)));
if (rechercher(a.cin)==1){gtk_label_set_text(GTK_LABEL(Fsortie_retirer),"l'ouvrier a été supprimer.");}
if (rechercher(a.cin)==0){gtk_label_set_text(GTK_LABEL(Fsortie_retirer),"verifier la cin ");}
supprimer_ouvrier(a);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void
on_Fnom_meilleur_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
char cin[30],B[30];
FILE *f;
ouvrier a;
GtkWidget *Fsortie_meilleur;
Fsortie_meilleur=lookup_widget(button,"Fsortie_meilleur");
f=fopen("ouvrier.txt","r");
if (f!=NULL){
 signed int heure,heures; 
 fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n",a.cin, a.nom, a.prenom, a.sexe ,a.tel,&a.age, &a.dt.jour, &a.dt.mois, &a.dt.ans, &a.abs, &a.supp);
 heure=a.supp-a.abs;
 strcpy(cin,a.cin);
 while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n",a.cin, a.nom, a.prenom, a.sexe ,a.tel,&a.age, &a.dt.jour, &a.dt.mois, &a.dt.ans, &a.abs, &a.supp)!=EOF)
  {heures=a.supp-a.abs;
   if (heures>heure){heure=heures;
                     strcpy(cin,a.cin);}
  }
 while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n",a.cin, a.nom, a.prenom, a.sexe ,a.tel,&a.age, &a.dt.jour, &a.dt.mois, &a.dt.ans, &a.abs, &a.supp)!=EOF)
 { if (strcmp(cin,a.cin)==0){strcpy(B,a.nom);
                             gtk_label_set_text(GTK_LABEL(Fsortie_meilleur),B);}}
            }
else{gtk_label_set_text(GTK_LABEL(Fsortie_meilleur),"le fichier est vide");}
fclose(f);  
}

