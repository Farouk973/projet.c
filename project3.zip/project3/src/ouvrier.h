#include <gtk/gtk.h> 

typedef struct {
int jour;
int mois;
int ans;
}date;

typedef struct {
char nom[300];// a z 
char prenom[300];
char cin[300];// 8 numero
char tel[300];//8 numero
char sexe[300]; 
int age; 
int abs;//nbr des jours d'absence
int supp;//nbr des heures supplimentair
date dt;
}ouvrier;
//int test2 ( const char *num);
//int test ( const char *num);
void ajouter_ouvrier(ouvrier a);
void affichier_ouvrier(GtkWidget *liste);
void supprimer_ouvrier(ouvrier a);
//int  test_u(const char * u);
void modifier__ouvrier(ouvrier a);
int alphabet(char z[300]);
int numbers(char v[300]);
int rechercher(char *cin);
char array[300];
char cin1[300];

