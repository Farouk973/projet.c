/*#include<stdio.h>

#include<string.h>




int main()
{


   

 const char  *tel = "[0-9]{8}";
  
 

}*/
#include<string.h>
#include <stdio.h>
#include <stdlib.h>
#include <regex.h>
#include<ctype.h>
int test (void)
{
   int err;
   regex_t preg;
   const char *str_request = "88551478";
   const char *str_regex = "[0-9]{8}$";
//"www\\.[-_[:alnum:]]+\\.[[:lower:]]{2,4}";


   err = regcomp (&preg, str_regex, REG_NOSUB | REG_EXTENDED);
   if (err == 0)
   {
      int match;


      match = regexec (&preg, str_request, 0, NULL, 0);

      regfree (&preg);

      if (match == 0)
      {
         printf ("%s est  phone number valide\n", str_request);
      }

      else if (match == REG_NOMATCH)
      {
         printf ("%s n\'est pas une adresse internet valide\n", str_request);
      }

      else
      {
         char *text;
         size_t size;

/* (7) */
         size = regerror (err, &preg, NULL, 0);
         text = malloc (sizeof (*text) * size);
         if (text)
         {
/* (8) */
            regerror (err, &preg, text, size);
            fprintf (stderr, "%s\n", text);
            free (text);
         }
         else
         {
            fprintf (stderr, "Memoire insuffisante\n");
            exit (EXIT_FAILURE);
         }
      }
   }
   puts ("\nPress any key\n");
/* Dev-cpp */
   getchar ();
   return (EXIT_SUCCESS);
}




int  test_u(const char * u){
    const char *ptr = u;
    while(ptr <ptr+ strlen(u) && *ptr !='\0')
      {
putc(*ptr,stdout);

             if(isalpha(*ptr)) ptr++;
              else  break; 
       } 
 if(ptr== ptr + strlen(u))

  return 1;

else return 0;
}
int test2 (const char *str_request)
{  

   int t_v = 0;
   int err;
   regex_t preg;
   
   const char *str_regex = "[a-zA-Z]$";
//"www\\.[-_[:alnum:]]+\\.[[:lower:]]{2,4}";

    if(test_u(str_request)==1) {
  
 err = regcomp (&preg, str_regex, REG_NOSUB | REG_EXTENDED);
   if (err == 0)
   {
      int match;


      match = regexec (&preg, str_request, 0, NULL, 0);

      regfree (&preg);

      if (match == 0)
      {
         printf ("%s est  phone number valide\n", str_request);

return 1;
      }

      else if (match == REG_NOMATCH)
      {
         printf ("%s n\'est pas une adresse internet valide\n", str_request);
return 0;
      }

      else
      {
         char *text;
         size_t size;

/* (7) */
         size = regerror (err, &preg, NULL, 0);
         text = malloc (sizeof (*text) * size);
         if (text)
         {
/* (8) */
            regerror (err, &preg, text, size);
            fprintf (stderr, "%s\n", text);
            free (text);
return 0;
         }
         else
         {
            fprintf (stderr, "Memoire insuffisante\n");
return 0;
            exit (EXIT_FAILURE);
         }
      }
   }
   //puts ("\nPress any key\n");
/* Dev-cpp */
  // getchar ();
  // return (EXIT_SUCCESS);
  } //else {return 0;}
}


int main()

{

//printf("ok");

   int r = 0 ; 
r=test2("hello");
printf("%d",r);
    if(r==1) printf("ok");
else printf("nop");

return 1;

}
