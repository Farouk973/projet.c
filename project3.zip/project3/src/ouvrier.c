#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "ouvrier.h"
#include <ctype.h>
#include<regex.h>



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ajouter_ouvrier(ouvrier a)
{
FILE *f;
f=fopen("ouvrier.txt","a+");
if (f!=NULL)
 {
	a.abs=0;
	a.supp=0;
	fprintf(f,"%s %s %s %s %s %d %d %d %d %d %d \n", a.cin, a.nom, a.prenom, a.sexe, a.tel, a.age, a.dt.jour, a.dt.mois, a.dt.ans,a.abs, a.supp);
	fclose(f);
 }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum
{
	ECIN,
	ENOM,
	EPRENOM,
	ESEXE,
	ETEL,
	EAGE,
	EDATE,
	EABS,
	ESUPP,
	COLUMNS
};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void affichier_ouvrier(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char cin[30];
	char nom[30];
	char prenom[30];
	char sexe[30];
	char tel[30];
        char date[30];
        char absd[30];
        char agef[30];
        char supd[30];
	int age;
	int jour;
	int mois;
	int ans;
	int abs;
	int supp;
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);


        if (store==NULL)	
	{
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",ECIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("tel",renderer,"text",ETEL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("age",renderer,"text",EAGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	/*renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("mois_ajouter",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("ans_ajouter",renderer,"text",EANS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);*/

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("abs",renderer,"text",EABS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes("supp",renderer,"text",ESUPP,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	
	f=fopen("ouvrier.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{

	 f=fopen("ouvrier.txt","r");
	 while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d",cin,nom,prenom,sexe,tel,&age,&jour,&mois,&ans,&abs,&supp)!=EOF)
	 {
                 sprintf(date,"%d /%d /%d",jour,mois,ans);
                 sprintf(absd,"%d ",abs);
                 sprintf(supd,"%d ",supp);
                 sprintf(agef,"%d ",age);
		 gtk_list_store_append(store,&iter);

		 gtk_list_store_set(store,&iter,ECIN,cin,ENOM,nom,EPRENOM,prenom,ESEXE,sexe,ETEL,tel,EAGE,agef,EDATE,date,EABS,absd,ESUPP,supd,-1);
	 }
	 fclose(f);
	 gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	 g_object_unref (store);
	}
      }
	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void supprimer_ouvrier(ouvrier a)
{
ouvrier a2;
FILE *f,*g;
	f=fopen("ouvrier.txt","r");
	g=fopen("ouvrier2.txt","w");

	if (f==NULL || g==NULL)
		return;
	else
	{
		while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n", a2.cin, a2.nom, a2.prenom, a2.sexe ,a2.tel,&a2.age, &a2.dt.jour, &a2.dt.mois, &a2.dt.ans, &a2.abs, &a2.supp)!=EOF)
		 {
			if(strcmp(a.cin,a2.cin)!=0 )
			fprintf(g,"%s %s %s %s %s %d %d %d %d %d %d \n",a2.cin, a2.nom, a2.prenom,a2.sexe, a2.tel, a2.age,a2.dt.jour, a2.dt.mois, a2.dt.ans, a2.abs, a2.supp);
		 }
		fclose(f);
		fclose(g);
		remove("ouvrier.txt");
		rename("ouvrier2.txt","ouvrier.txt");
        }

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int alphabet(char z[30])
{int i=0,test=1;
 if (strlen(z)==0) {return(0);}
 else{  
	do
	{
	if (isalpha(z[i])==0||z[i]==" "){test=0;}
	i++;
	}while((test==1)&& (i<strlen(z)));
        return(test);
     }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int numbers(char v[30])
{int i=0,test=1;
 if (strlen(v)!=8) return(0);
 else{
	do
	{
	if (isdigit(v[i])==0){test=0;}
	i++;         
	}while((test==1)&& (i<strlen(v)));
        return(test);
      }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*int recherchecin(char st[30])
{
 FILE *f;
 char array[30];
 int id,x;
 int test=0,i=0;
 f=fopen("ouvrier.txt","r");
if (f==NULL) return 0;
else{
	do{
	 fscanf(f,"%s",array);
	 id=atoi(array);
	 x=atoi(st);
	 if (id==x){test=1;}
	i++;
	  }while (test==0&&i!=EOF);
     return(test);
     }
}*/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*void modifier_client(client c)

{
client c3;
FILE *f,*k;
    f=fopen("client.txt","r");
    k=fopen("client3.txt","w");

if (f!=NULL) 
{
     while(fscanf(f,"%s %s %s %s %s %d %d %d %s %s %s ",c3.carteid,c3.nom,c3.prenom,c3.login,c3.password,&c3.d.jour,&c3.d.mois,&c3.d.annee,c3.num,c3.adresse,c3.sexe)!=EOF)
       { if (strcmp(c.carteid,c3.carteid)!=0  )
fprintf(k,"%s %s %s %s %s %d %d %d %s %s %s  \n ",c3.carteid,c3.nom,c3.prenom,c3.login,c3.password,c3.d.jour,c3.d.mois,c3.d.annee,c3.num,c3.adresse,c3.sexe);
else {fprintf(k,"%s %s %s %s %s %d %d %d %s %s %s  \n ",c.carteid,c.nom,c.prenom,c.login,c.password,c.d.jour,c.d.mois,c.d.annee,c.num,c.adresse,c.sexe);
}
}

fclose(f);
fclose(k);
remove("client.txt");
rename("client3.txt","client.txt");
}
}*/
void modifier__ouvrier(ouvrier a)
{
ouvrier o;
FILE *f,*k;
f=fopen("ouvrier.txt","r");
k=fopen("ouvrier3.txt","w");
if (f!=NULL) 
{
     while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n", o.cin, o.nom, o.prenom, o.sexe ,o.tel,&o.age, &o.dt.jour, &o.dt.mois, &o.dt.ans, &o.abs, &o.supp)!=EOF)
{if(strcmp(array,o.cin)!=0 )
    
   fprintf(k,"%s %s %s %s %s %d %d %d %d %d %d \n",o.cin, o.nom, o.prenom,o.sexe, o.tel, o.age,o.dt.jour, o.dt.mois, o.dt.ans, o.abs, o.supp);
else fprintf(k,"%s %s %s %s %s %d %d %d %d %d %d \n",a.cin, a.nom, a.prenom,a.sexe, a.tel, a.age,a.dt.jour, a.dt.mois, a.dt.ans, o.abs, o.supp);
}

fclose(f);
fclose(k);
remove("ouvrier.txt");
rename("ouvrier3.txt","ouvrier.txt");
}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
int rechercher(char *carteid)
{
FILE *f;
client c;
int k=0;
f=fopen("client.txt","r");
if (f!=NULL) 
{ while(fscanf(f,"%s %s %s %s %s %d %d %d %s %s %s ",c.carteid,c.nom,c.prenom,c.login,c.password,&c.d.jour,&c.d.mois,&c.d.annee,c.num,c.adresse,c.sexe)!=EOF)
       { if (strcmp(carteid,c.carteid)==0  )
        k=1;
     

}
fclose(f);
return(k);
}
}
*/
int rechercher(char *cin)
{
FILE *f;
ouvrier a;
int k=0;
f=fopen("ouvrier.txt","r");
if (f!=NULL) 
{ while(fscanf(f,"%s %s %s %s %s %d %d %d %d %d %d \n", a.cin, a.nom, a.prenom, a.sexe ,a.tel,&a.age, &a.dt.jour, &a.dt.mois, &a.dt.ans, &a.abs, &a.supp)!=EOF)
       { if (strcmp(cin,a.cin)==0  )
        k=1;
     

}
fclose(f);
return(k);
}
}
