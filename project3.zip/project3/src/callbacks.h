#include <gtk/gtk.h>


void
on_Fretourner_gestion_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fajouter_gestion_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fsupprimer_gestion_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Finfo_gestion_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fmeilleur_gestion_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fajouter_ajouter_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fannuler_ajouter_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fanuuler_retirer_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fsupprimer_supprimer_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fannuler_modifier_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fenregistrer_modifier_clicked       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview_ouvrier_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Fmodifier_info_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fretourner_info_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Ftree_info_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Fhomme_ajouter_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Ffemme_ajouter_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Fretourner_meilleur_clicked         (GtkWidget       *button,
                                        gpointer         user_data);



void
on_Ffemme_win_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Fhomme_win_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Fannuler_win_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fchercher_win_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fmodifier_win_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_entrer_verifier_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourner_verifier_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fmodifier_info_ouvrier_clicked      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Fnom_meilleur_clicked               (GtkWidget       *button,
                                        gpointer         user_data);
