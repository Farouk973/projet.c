#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "fonction.h"
#include <gtk/gtk.h>


void ajouter_troupeaux(troupeaux t)
{

 FILE *fa;
  fa=fopen("bloc.txt","a+");
  if(fa!=NULL) 
  {
  fprintf(fa,"%s %s %s %d/%d/%d  \n",t.identifiant,t.sexe,t.type,t.tra.jour,t.tra.mois,t.tra.annee);
  fclose(fa);
}

}


enum   
{       
        EIDENTIFIANT,
	ETYPE,
        EDATE,
	ESEXE,
     
        COLUMNS
};
void afficher_troupeaux(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
        char identifiant [30];
        char type [30];
        char date [30] ;
	char sexe[30];
        
        store=NULL;
       FILE *f;
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" identifiant", renderer, "text",EIDENTIFIANT,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" sexe", renderer, "text",ESEXE,NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" type ", renderer, "text",ETYPE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	

	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  date", renderer, "text",EDATE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING);

	f = fopen("bloc.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("bloc.txt", "a+");
              while(fscanf(f," %s %s %s %s  \n",identifiant,sexe,type,date)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, EIDENTIFIANT, identifiant,ESEXE,sexe, ETYPE, type, EDATE, date, -1);
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}

void supprimer_troupeaux(char id[])
{
troupeaux t;

FILE*fa;
FILE*ffact;

char date[50];
char type[50];
char identifiant[50];



fa = fopen("bloc.txt","r");
ffact = fopen("bloc2.txt","w+");


while (fscanf(fa,"%s %s %s %s  \n",t.identifiant,t.sexe,t.type,date)!=EOF)
 {

            if(strcmp(t.identifiant,id)!=0)
            {
                fprintf(ffact,"%s %s %s %s \n",t.identifiant,t.sexe,t.type,date);
                
        }
        


    }

    fclose(ffact);
    fclose(fa);

     remove("bloc.txt");
     rename("bloc2.txt","bloc.txt");

}



void modifier_t(  char idd[], char sexe[],char typee[],char date1[] )
   {char date[30];
	troupeaux t;
	FILE *fa;
	FILE *fmodif;
	fa=fopen("bloc.txt","r");
	fmodif=fopen("modif.txt","a+");
	if (fa!=NULL)
	{
	while (fscanf(fa,"%s %s %s %s \n",t.identifiant,t.sexe,t.type,date)!=EOF)
               
	{
		
		if(strcmp(idd,t.identifiant)!=0)
		{
			fprintf(fmodif,"%s %s %s %s  \n",t.identifiant,t.sexe,t.type,date);
		}
		else
		{
			fprintf(fmodif,"%s %s %s %s   \n",idd,sexe,typee,date1);

		}
	}
	fclose(fmodif);
	fclose(fa);
	remove("bloc.txt");
	rename("modif.txt","bloc.txt");
	

	}}
