#include <gtk/gtk.h>
typedef struct
{

        int jour;
	int mois;
	int annee;


}Date;


typedef struct
{
	char sexe [30];
        char identifiant [30];
        char type [30];
	Date tra;


}troupeaux;



void ajouter_troupeaux(troupeaux t);
void afficher_troupeaux(GtkWidget *liste);
void modifier_t(  char idd[], char sexe[],char typee[],char date1[] );
void supprimer_troupeaux(char id[]);

