#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "trouv.h"

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *username, *password, *window22, *label49;
char user[20];
char pasw[20];
int trouve;
label49=lookup_widget(button,"label49");
username=lookup_widget (button,"entry1");
password=lookup_widget (button,"entry2");

strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=verif(user,pasw);

if(trouve==1)
{
window22=create_window2();
gtk_widget_show (window22);
}
else 
gtk_label_set_text(GTK_LABEL(label49),"nom au mot de passe incorrecte");
}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window33;
window33=create_window3();
gtk_widget_show (window33);
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window11;
window11=create_window1();
gtk_widget_show (window11);
}




void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window22;
window22=create_window2();
gtk_widget_show (window22);
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window33;
window33=create_window3();
gtk_widget_show (window33);
}


void
on_button13_clicked                    (GtkWidget       *obj, gpointer         user_data)
{
GtkWidget *entry3; 

GtkWidget *combobox1;
GtkWidget  *spin3;
GtkWidget  *spin4;
GtkWidget  *spin5;
GtkWidget *radiobutton3;
GtkWidget *radiobutton2;

troupeaux t;
GSList *List; GSList* gtk_radio_button_get_group(GtkRadioButton *radio_button);

//////////////////////////////




radiobutton3=lookup_widget(GTK_WIDGET(obj),"radiobutton3"); radiobutton2=lookup_widget(GTK_WIDGET(obj),"radiobutton2"); /////////////////////
List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton3)); ////////////////////////////////////



if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data))) strcpy(t.sexe,gtk_button_get_label(GTK_BUTTON(List->data))); else {List = g_slist_next(List); strcpy(t.sexe,gtk_button_get_label(GTK_BUTTON(List->data)));}



entry3=lookup_widget(obj,"entry3");
combobox1=lookup_widget(obj,"combobox1");
spin3=lookup_widget(obj,"spinbutton3");
spin4=lookup_widget(obj,"spinbutton4");
spin5=lookup_widget(obj,"spinbutton5");



strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
t.tra.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin3));
t.tra.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin4));
t.tra.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin5));




ajouter_troupeaux(t);
}


void
on_button12_clicked                    (GtkWidget       *obj,
                                        gpointer         user_data)
{
GtkWidget *window5;
	GtkWidget *treeview11;

	window5=lookup_widget(obj,"window5");
	treeview11=lookup_widget(window5,"treeview1");

	afficher_troupeaux(treeview11);

}

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window33;
window33=create_window3();
gtk_widget_show (window33);
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window66;
window66=create_window6();
gtk_widget_show (window66);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window77;
window77=create_window7();
gtk_widget_show (window77);
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window55;
window55=create_window5();
gtk_widget_show (window55);
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window88;
window88=create_window7();
gtk_widget_show (window88);
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window44;
window44=create_window4();
gtk_widget_show (window44);

}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char id[50];

	GtkWidget *entry4;
	entry4=lookup_widget(button,"entry4");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry4)));

	supprimer_troupeaux(id);
	
}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window33;
window33=create_window3();
gtk_widget_show (window33);
}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button17_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
char idd[50];
	char typee[50];
	char date1[50];
	char sexe[50];

	GtkWidget *entry5;
	GtkWidget *entry6;
	GtkWidget *entry8; 
	GtkWidget *entry7; 
	
	entry5=lookup_widget(button,"entry5");
	strcpy(idd,gtk_entry_get_text(GTK_ENTRY(entry5)));
	entry6=lookup_widget(button,"entry6");
	strcpy(typee,gtk_entry_get_text(GTK_ENTRY(entry6)));
	entry8=lookup_widget(button,"entry8");
	strcpy(date1,gtk_entry_get_text(GTK_ENTRY(entry8)));
	entry7=lookup_widget(button,"entry7");
	strcpy(sexe,gtk_entry_get_text(GTK_ENTRY(entry7)));
	 modifier_t(idd,sexe,typee,date1);
}


void
on_button18_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *entry5;
GtkWidget *entry6;
GtkWidget *entry8;
GtkWidget *entry7;
FILE *fa;
char id1[50];
troupeaux t;
char date[50];
fa=fopen("bloc.txt","r");
entry5=lookup_widget(objet,"entry5");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(entry5)));
if (fa!=NULL)
 {
    	while(fscanf(fa,"%s %s %s %s \n",t.identifiant,t.sexe,t.type,date)!=EOF)
 {
			if(strcmp(id1,t.identifiant)==0){

				entry5=lookup_widget(objet,"entr5");
				entry6=lookup_widget(objet,"entry6");
				entry7=lookup_widget(objet,"entry7");
				entry8=lookup_widget(objet,"entry8");
				gtk_entry_set_text(GTK_ENTRY(entry5),t.identifiant);
				gtk_entry_set_text(GTK_ENTRY(entry7),t.sexe);
				gtk_entry_set_text(GTK_ENTRY(entry6),t.type);
				gtk_entry_set_text(GTK_ENTRY(entry8),date);
				
			}
				
				

		}

}



}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry9;
GtkWidget *entry10;
GtkWidget *entry12;
FILE *fa;
char id1[50];
troupeaux t;
char date[50];
fa=fopen("bloc.txt","r");
entry9=lookup_widget(button,"entry9");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(entry9)));
if (fa!=NULL)
 {
    	while(fscanf(fa,"%s %s %s \n",t.identifiant,t.sexe,t.type,date)!=EOF)
 {
			if(strcmp(id1,t.identifiant)==0){

				entry9=lookup_widget(button,"entry9");
				entry10=lookup_widget(button,"entry10");
				entry12=lookup_widget(button,"entry12");
				gtk_entry_set_text(GTK_ENTRY(entry9),t.identifiant);
				gtk_entry_set_text(GTK_ENTRY(entry10),t.type);
				gtk_entry_set_text(GTK_ENTRY(entry12),date);
				
			}
				
				

		}

}



}




void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}

